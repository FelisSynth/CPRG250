SPOOL c:/cprg250s/report4output.txt
-- starting settings
SET ECHO OFF
SET VERIFY OFF
SET FEEDBACK OFF
set linesize 85
set pagesize 66 
CLEAR COLUMNS
CLEAR BREAKS

SELECT coursename, city, prov, postalcode, country, lengthinyards, yearbuild, count(teetimeid)"# of Tee time"
FROM Foreever_course_information JOIN fg_teetimes ON coursename = course_id 
Group BY coursename, city, prov, postalcode, country, lengthinyards, yearbuild;

COLUMN course_id HEADING 'Course Name'
COLUMN teetimes HEADING 'Tee Time'
COLUMN numberofholes HEADING 'Number Of Holes'
COLUMN availableSpace HEADING 'Availability'

SELECT course_id, teetimes "Tee time(appointment time)", numberofholes, availableSpace, SUM(priceperplayer)"price"
FROM fg_teeTimes
GROUP BY 
grouping sets(
    (course_id, teetimes, numberofholes, availableSpace),
    (course_id),
    ()
)
order by course_id;


SPOOL OFF
TTITLE OFF
CLEAR BREAKS
CLEAR COMPUTES