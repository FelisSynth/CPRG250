SPOOL c:/cprg250s/report1output.txt
-- starting settings
SET ECHO OFF
SET VERIFY OFF
SET FEEDBACK OFF
set linesize 85
set pagesize 66 
CLEAR COLUMNS
CLEAR BREAKS

-- formatting title
TTITLE CENTER 'Customer Sales Report' SKIP 2
BTITLE OFF
BREAK ON customer SKIP 1 ON report

COMPUTE SUM LABEL 'Customer Total' of price on customer
COMPUTE SUM LABEL 'Total' of price on report

COLUMN customer FORMAT 'A20' HEADING 'Customer Name'
COLUMN coursename FORMAT 'A20' HEADING 'Course Name'
COLUMN card FORMAT 'A20' HEADING 'Card Type'
COLUMN price FORMAT $9,990.00 HEADING 'Amount Charged'

Select INITCAP(CONCAT(firstname, CONCAT(' ', lastname))) "customer", course_id "coursename", cardname "card", amountcharged "price"
from ForeEver_Customer join ForeEver_Reservation on (customernumber = customer_id)
join ForeEver_Credit_Cards on (cardnumber = credit_card_id)
join fg_teeTimes on (teeTimeId = Tee_Time_ID)
group by INITCAP(CONCAT(firstname, CONCAT(' ', lastname))), course_id, cardname, amountcharged
order by INITCAP(CONCAT(firstname, CONCAT(' ', lastname))), course_id, cardname, amountcharged;


SPOOL OFF
TTITLE OFF
CLEAR BREAKS
CLEAR COMPUTES
