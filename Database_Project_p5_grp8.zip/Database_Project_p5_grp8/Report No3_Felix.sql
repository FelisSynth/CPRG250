SPOOL c:/cprg250s/AveragePricePerCourse.txt

SET ECHO OFF
SET VERIFY OFF
SET FEEDBACK OFF
set linesize 85
set pagesize 66 
CLEAR COLUMNS
CLEAR BREAKS

TTITLE CENTER 'Average Price per Course' SKIP 2
BTITLE OFF
BREAK ON course_id SKIP 1 ON report

COMPUTE AVG LABEL 'Course Average' of price on course_id
COMPUTE SUM LABEL 'Average Total' of price on report

COLUMN course_id FORMAT 'A20' HEADING 'Course Name'
COLUMN duration FORMAT 9 HEADING 'Tee time Duration'
COLUMN holes FORMAT 99 HEADING 'Holes'
COLUMN price FORMAT $90.00 HEADING 'Price'

Select INITCAP(course_id) "course_id", teeTimes "duration", numberOfHoles "holes", pricePerPlayer "price"
from fg_teeTimes
GROUP BY INITCAP(course_id), teeTimes, numberOfHoles, pricePerPlayer
ORDER BY INITCAP(course_id), teeTimes, numberOfHoles, pricePerPlayer;

SPOOL OFF
TTITLE OFF
CLEAR BREAKS
CLEAR COMPUTES
