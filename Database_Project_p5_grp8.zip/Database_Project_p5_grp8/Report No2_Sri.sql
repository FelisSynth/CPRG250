SPOOL c:/cprg250s/report2output.txt
-- starting settings
SET ECHO OFF
SET VERIFY OFF
SET FEEDBACK OFF
set linesize 85
set pagesize 66 
CLEAR COLUMNS
CLEAR BREAKS

-- formatting title
TTITLE CENTER 'Customer Who Contributed high Star Ratings' SKIP 2
BTITLE OFF
BREAK ON customer SKIP 1 ON report

COLUMN customer FORMAT 'A20' HEADING 'Customer Name'
COLUMN reviewTitle FORMAT 'A20' HEADING 'Review Short Title'
COLUMN starRating FORMAT 9 HEADING 'Star Rating'

--Finding the customers who gave ratings 4 and above
select INITCAP(CONCAT(firstname, CONCAT(' ', lastname))) "customer", reviewTitle, starRating
from ForeEver_Customer join ForeEver_Reservation on (customernumber = customer_id)
join fg_customerReview on (reservationId = Reservation_Id)
where Reservation_Id IN (Select Reservation_Id from fg_customerReview where starRating >= 4);



SPOOL OFF
TTITLE OFF
CLEAR BREAKS
CLEAR COMPUTES
