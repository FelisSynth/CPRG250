First to begin the populating process, we will take the script used to make the initial BuildDB
we're going to start by populating ForeEver_Course_Information

    - Using the golfnow.com site as a guide, we can get information on some golf course 
    and use that information to input into our table. For this lab we will only need 5 
    courses, along with its related values: Course Name, City, Province, Rating, 
    Description, Year, and Length.

    - Next is ForeEver_Customer which we populated using random datas. For this 
    we only need 3 users which need the values: Customer Number, First Name,
    Last Name, Email and Credit Amount.

    - Next is ForeEver_Customer_Course, this is a bridging table between 
    ForeEver_Customer and ForeEver_Course_Information so we're only need 3 
    rows for this one and each rows will have 3 values: Customer Number, Course Name, 
    and a combination of the two values mentioned.

    - Next is fg_TeeTimes which is a table for Tee Times, for this we just look on the
    site for some reasonable price for each tee time and we assigned 3 tee times to 
    each course. Each row will have: ID, Duration, Price, Cart Flag, Number of Holes, 
    Space Available, Cart Included ID and a Course ID.

    - Next is the ForeEver_Credit_Cards, again this will have random data put into it.
    Each row will have: Card Number, Name on Card, Expiry Date, and a number to indicate
    if this is the default card or not

    - Next is ForeEver_Reservation, which have: ID, Green Fee, Tax, Amount of Money charged
    Number of Player, Customer ID, Tee Time ID, and a Credit Card ID.

    - Next is the ForeEver_Rewards, which have: Promocode, Used ID, Issued Date, Vaue of Promocode
    Expiry Date, Customer ID and a Reservation ID.

    -Lastly will be the fg_customerReview, which will have: Title, Comment and Reservation ID.

Above is a list of table that needed to populate with it's require data. the list also show the
exact order that these table needed to be created