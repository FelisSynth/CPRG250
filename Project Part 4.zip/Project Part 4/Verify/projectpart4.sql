rem ForeEver Golf
rem
rem creating tables and adding constraints for ForeEver Golf using the provided physical ERD


-- To rerun script multiple times, the script starts by dropping the tables

spool c:/cprg250s/ForeEver_Golf_Grp8_verify.txt

--put your sql commands below


set echo on
set linesize 132
set pagesize 66 


--drop all tables, child tables first, then parent tables
DROP TABLE ForeEver_Customer_Course;
DROP TABLE ForeEver_Rewards;
DROP TABLE fg_customerReview;
DROP TABLE ForeEver_Reservation;
DROP TABLE ForeEver_Credit_Cards;
drop table fg_teeTimes; 

DROP TABLE ForeEver_Customer;
DROP TABLE ForeEver_Course_Information;



--create table ForeEver_Course_Information
CREATE TABLE ForeEver_Course_Information
(
CourseName VARCHAR2(13) CONSTRAINT FE_CINFO_NAME_PK PRIMARY KEY, 
city VARCHAR2(15) CONSTRAINT FE_CINFO_CITY_NN NOT NULL, 
Prov VARCHAR2(7) CONSTRAINT FE_CINFO_PROV_NN NOT NULL, 
PostalCode VARCHAR2(7) CONSTRAINT FE_CINFO_PCODE_NN NOT NULL, 
country VARCHAR2(6) CONSTRAINT FE_CINFO_COUNTRY_NN NOT NULL, 
AverageReviewRating Number(1) CONSTRAINT FE_CINFO_AVGREV_NN NOT NULL, 
Description VARCHAR2(15) CONSTRAINT FE_CINFO_DESC_NN NOT NULL, 
YearBuild number(4) CONSTRAINT FE_CINFO_YB_NN NOT NULL, 
LengthInYards number CONSTRAINT FE_CINFO_LIY_NN NOT NULL, 
CONSTRAINT FE_CINFO_AVGREV_CK CHECK(AverageReviewRating >=1 AND AverageReviewRating <= 5), 
CONSTRAINT FE_CINFO_PCODE_CK CHECK(REGEXP_LIKE(PostalCode, '[A-Z]{1}[0-9]{1}[A-Z]{1} [0-9]{1}[A-Z]{1}[0-9]{1}'))
);
DESC ForeEver_Course_Information;

INSERT INTO ForeEver_Course_Information
VALUES ('Richmond Hill', 'Toronto', 'Ontario', 'L4C 0H4', 'Canada', 4, 'Richmond Hill', 1992, 6004);
INSERT INTO ForeEver_Course_Information
VALUES ('Mill Run', 'Uxbridge', 'Ontario', 'L9P 1O1', 'Canada', 4, 'Mill Run', 2007, 5402);
INSERT INTO ForeEver_Course_Information
VALUES ('Shawneeki', 'Sharon', 'Ontario', 'L0G 1V0', 'Canada', 3, 'Shawneeki', 1947, 5472);
INSERT INTO ForeEver_Course_Information
VALUES ('Remington', 'Markham', 'Ontario', 'L3S 3J5', 'Canada', 4, 'Remington', 1960, 6800);
INSERT INTO ForeEver_Course_Information
VALUES ('Lakeview', 'Mississauga', 'Ontario', 'L5E 2P4', 'Canada', 4, 'Lakeview', 1907, 6344);

SELECT * FROM ForeEver_Course_Information;


--create table ForeEver_Customer
CREATE TABLE ForeEver_Customer
(
customerNumber NUMBER CONSTRAINT FE_customerNumber_PK PRIMARY KEY, 
firstName VARCHAR2(25) CONSTRAINT Customer_firstName_NN NOT NULL, 
lastName VARCHAR2(25) CONSTRAINT Customer_lastName_NN NOT NULL, 
Email VARCHAR2(25) CONSTRAINT Customer_email_NN NOT NULL,  
creditAmount NUMBER CONSTRAINT Customer_creditAmount_NN NOT NULL,  
CONSTRAINT Customer_email_CK CHECK (Email like'%_@__%.__%'), 
CONSTRAINT Customer_creditAmount_CK CHECK (creditAmount >= 0)
);

DESC ForeEver_Customer;

INSERT INTO ForeEver_Customer
VALUES (1, 'Millie', 'Gibbons', 'millie@gmail.com', 50.00);
INSERT INTO ForeEver_Customer
VALUES (2, 'Albert', 'Bravo', 'albert@gmail.com', 40.00);
INSERT INTO ForeEver_Customer
VALUES (3, 'Tania', 'Hale', 'tania@gmail.com', 0.00);

SELECT * FROM ForeEver_Customer;

--create table ForeEver_Customer_Course
CREATE TABLE ForeEver_Customer_Course
(
CustomerNumber NUMBER CONSTRAINT FE_CC_CNUM_NN NOT NULL, 
CourseName VARCHAR2(50) CONSTRAINT FE_CC_CNAME_NN NOT NULL, 
CustomerNumber_CourseName VARCHAR2(52) CONSTRAINT FE_CC_CNCN_PK PRIMARY KEY, 
CONSTRAINT FE_CC_CNUM_FK1 FOREIGN KEY(CustomerNumber) REFERENCES ForeEver_Customer(CustomerNumber), 
CONSTRAINT FE_CC_CNUM_CK CHECK(CustomerNumber >= 0), 
CONSTRAINT FE_CC_CNAME_FK2 FOREIGN KEY(CourseName) REFERENCES ForeEver_Course_Information(CourseName)
);

DESC ForeEver_Customer_Course;

INSERT INTO ForeEver_Customer_Course
VALUES (1, 'Richmond Hill', '1_ Richmond Hill');
INSERT INTO ForeEver_Customer_Course
VALUES (2, 'Remington', '2_Remington');
INSERT INTO ForeEver_Customer_Course
VALUES (3, 'Shawneeki', '3_Shawneeki');

SELECT * FROM ForeEver_Customer_Course;

--create table for tee Times, use alter table commands to add constraints 

CREATE TABLE fg_teeTimes 
(
teeTimeId NUMBER CONSTRAINT Tee_Times_Id_PK PRIMARY KEY, 
teeTimes NUMBER CONSTRAINT Tee_Times_Duration_NN NOT NULL, 
pricePerPlayer NUMBER(6, 2) CONSTRAINT Tee_Times_Price_NN NOT NULL, 
cartFlag NUMBER(1) CONSTRAINT Tee_Times_Cart_Flag_NN NOT NULL, 
numberOfHoles NUMBER CONSTRAINT Tee_Times_Holes_NN NOT NULL, 
availableSpace NUMBER CONSTRAINT Tee_Times_Spaces_NN NOT NULL, 
cartIncluded char(1) CONSTRAINT Tee_Times_Cart_Included_NN NOT NULL, 
Course_ID VARCHAR2(50)
);

ALTER TABLE fg_teeTimes
add CONSTRAINT Tee_Times_Course_ID_FK FOREIGN KEY(Course_ID) REFERENCES ForeEver_Course_Information(CourseName)
add CONSTRAINT Tee_Times_Holes_CK CHECK(numberOfHoles == 9 or numberOfHoles == 18), 
add CONSTRAINT Tee_Times_Price_CK CHECK(pricePerPlayer >= 0), 
add CONSTRAINT Tee_Times_Cart_Included_CK CHECK(SUBSTR(Product_id, 1, 1) ='Y' OR SUBSTR(Product_id, 1, 1) ='N'), 
add CONSTRAINT Tee_Times_Cart_Flag_CK CHECK(cartFlag == 0 OR cartFlag == 1), 
add CONSTRAINT Tee_Times_Spaces_CK CHECK(0 <= availableSpace <= 4)

DESC fg_teeTimes

INSERT INTO fg_teeTimes
VALUES (1, 3, 45.00, 1, 18, 0, 'Y', 'Richmond Hill');
INSERT INTO fg_teeTimes
VALUES (2, 4, 50.00, 1, 18, 1, 'Y', 'Richmond Hill');
INSERT INTO fg_teeTimes
VALUES (3, 2, 38.95, 0, 9, 1, 'N', 'Richmond Hill');
INSERT INTO fg_teeTimes
VALUES (4, 2, 35.00, 1, 9, 0, 'Y', 'Mill Run');
INSERT INTO fg_teeTimes
VALUES (5, 3, 42.95, 0, 18, 1, 'N', 'Mill Run');
INSERT INTO fg_teeTimes
VALUES (6, 4, 50.95, 1, 18, 1, 'Y', 'Mill Run');
INSERT INTO fg_teeTimes
VALUES (7, 2, 35.55, 0, 9, 0, 'N', 'Shawneeki');
INSERT INTO fg_teeTimes
VALUES (8, 4, 59.95, 1, 18, 0, 'Y', 'Shawneeki');
INSERT INTO fg_teeTimes
VALUES (9, 3, 49.95, 1, 18, 1, 'Y', 'Shawneeki');
INSERT INTO fg_teeTimes
VALUES (10, 4, 58.50, 0, 18, 0, 'N', 'Remington');
INSERT INTO fg_teeTimes
VALUES (11, 2, 38.95, 1, 9, 1, 'Y', 'Remington');
INSERT INTO fg_teeTimes
VALUES (12, 3, 48.95, 0, 18, 0, 'N', 'Remington');
INSERT INTO fg_teeTimes
VALUES (13, 3, 30.00, 1, 18, 1, 'Y', 'Lakeview');
INSERT INTO fg_teeTimes
VALUES (14, 2, 40.00, 1, 9, 0, 'Y', 'Lakeview');
INSERT INTO fg_teeTimes
VALUES (15, 4, 50.00, 0, 18, 1, 'N', 'Lakeview');

SELECT * FROM fg_teeTimes;



--create table ForeEver_Credit_Cards
CREATE TABLE ForeEver_Credit_Cards 
( 
cardNumber NUMBER CONSTRAINT Credit_Card_Number_PK PRIMARY KEY, 
cardName VARCHAR2(25) CONSTRAINT Credit_Card_Name_NN NOT NULL, 
expiryDate VARCHAR2(4) CONSTRAINT Credit_Card_EXP_NN NOT NULL, 
default_card NUMBER(1) CONSTRAINT Credit_Card_Default_NN NOT NULL,  
Customer_ID NUMBER, 
CONSTRAINT Credit_Card_Default_CK CHECK(default_card >= 0 AND default_card <= 1), 
CONSTRAINT Credit_Card_EXP_CK CHECK(REGEXP_LIKE(expiryDate, '(0[1-9]||1[0-2])([0-9]{2})')), 
CONSTRAINT Credit_Card_Customer_Id_FK FOREIGN KEY(Customer_ID) REFERENCES ForeEver_Customer(customerNumber)
); 

DESC ForeEver_Credit_Cards;

INSERT INTO ForeEver_Credit_Cards
VALUES (100, 'master', 1224, 0, 1);
INSERT INTO ForeEver_Credit_Cards
VALUES (200, 'visa', 1123, 1, 1);
INSERT INTO ForeEver_Credit_Cards
VALUES (300, 'american_express', 1024, 0, 2);
INSERT INTO ForeEver_Credit_Cards
VALUES (400, 'visa', 0823, 1, 2);
INSERT INTO ForeEver_Credit_Cards
VALUES (500, 'american_express', 1222, 1, 3);

SELECT * FROM ForeEver_Credit_Cards;

--create table ForeEver_Reservation
CREATE TABLE ForeEver_Reservation
(
reservationId NUMBER CONSTRAINT Reservation_ID_PK PRIMARY KEY, 
greenFees NUMBER(6, 2) CONSTRAINT Reservation_Green_Fees_NN NOT NULL, 
taxes NUMBER(6, 2) CONSTRAINT Reservation_Tax_NN NOT NULL, 
amountCharged NUMBER(6, 2) CONSTRAINT Reservation_Amount_NN NOT NULL, 
numberOfPlayer NUMBER CONSTRAINT Reservation_Number_Of_Player_NN NOT NULL, 
Customer_ID NUMBER,  
Tee_Time_ID NUMBER, 
Credit_Card_ID NUMBER, 
CONSTRAINT Reservation_Customer_Id_FK FOREIGN KEY(Customer_ID) REFERENCES ForeEver_Customer(customerNumber), 
CONSTRAINT Reservation_Tee_Time_Id_FK FOREIGN KEY(Tee_Time_ID) REFERENCES fg_teeTimes(teeTimeId), 
CONSTRAINT Reservation_Credit_Card_Id_FK FOREIGN KEY(Credit_Card_ID) REFERENCES ForeEver_Credit_Cards(cardNumber)
); 

DESC ForeEver_Reservation;

INSERT INTO ForeEver_Reservation
VALUES (1001, 0, 0, 0, 1, 1, 3, 200);
INSERT INTO ForeEver_Reservation
VALUES (1002, 0, 0, 0, 3, 2, 10, 400);
INSERT INTO ForeEver_Reservation
VALUES (1003, 0, 0, 0, 4, 1, 1, 100);
INSERT INTO ForeEver_Reservation
VALUES (1004, 0, 0, 0, 1, 3, 7, 500);
INSERT INTO ForeEver_Reservation
VALUES (1005, 0, 0, 0, 4, 3, 9, 500);

UPDATE ForeEver_Reservation
SET taxes = greenFees * 0.5;

UPDATE ForeEver_Reservation
SET amountCharged = greenFees + taxes;

SELECT * FROM ForeEver_Reservation;

--create table ForeEver_Rewards
CREATE TABLE ForeEver_Rewards
(
promoCode VARCHAR2(18) CONSTRAINT FE_promoCode_PK PRIMARY KEY, 
isUsed NUMBER(1) CONSTRAINT Reward_Is_Used_NN NOT NULL, 
issuedDate DATE CONSTRAINT Reward_Date_Issued_NN NOT NULL, 
promocodeValue NUMBER(6, 2) CONSTRAINT Reward_value_NN NOT NULL, 
expiryDate VARCHAR2(4) CONSTRAINT Reward_Expiry_Date_NN NOT NULL, 
CustomerID NUMBER, 
ReservationID NUMBER, 
CONSTRAINT Reward_Customer_Id_FK FOREIGN KEY(CustomerID) REFERENCES ForeEver_Customer(customerNumber), 
CONSTRAINT Reward_Reservation_Id_FK FOREIGN KEY(ReservationID) REFERENCES ForeEver_Reservation(reservationId), 
CONSTRAINT Reward_Is_Used_CK CHECK(isUsed >= 0 AND isUsed <= 1), 
CONSTRAINT Reward_Expiry_Date_CK CHECK(REGEXP_LIKE(expiryDate, '(0[1-9]||1[0-9]||2[0-9]||3[0-1])(0[1-9]||1[0-2])'))
);

DESC ForeEver_Rewards;

INSERT INTO ForeEver_Rewards
VALUES ('gHiHVcvi2ULCSLHLAb', 0, '01-JAN-22', 20.54, 2212, 1, 1001);
INSERT INTO ForeEver_Rewards
VALUES ('7vhZ6KCKYktxDV5AUY', 1, '03-JAN-22', 10.75, 1503, 2, 1002);
INSERT INTO ForeEver_Rewards
VALUES ('Ng38tqsmc32WWDFSMk', 0, '05-JAN-22', 15.30, 1012, 1, NULL);
INSERT INTO ForeEver_Rewards
VALUES ('9c2Z5kjmfqfQfURQBB', 1, '10-JAN-22', 25.50, 0902, 3, 1005);
INSERT INTO ForeEver_Rewards
VALUES ('eahoDsAYFUDkeQ4fpm', 1, '11-FEB-22', 12.50, 2311, 2, NULL);

SELECT * FROM ForeEver_Rewards;

--Get green fees

UPDATE ForeEver_Reservation
SET greenFees = (SELECT pricePerPlayer FROM fg_teeTimes WHERE teeTimeId = 3)
WHERE reservationId = '1001';
UPDATE ForeEver_Reservation
SET greenFees = (SELECT pricePerPlayer FROM fg_teeTimes WHERE teeTimeId = 10)
WHERE reservationId = '1002';
UPDATE ForeEver_Reservation
SET greenFees = (SELECT pricePerPlayer FROM fg_teeTimes WHERE teeTimeId = 1)
WHERE reservationId = '1003';
UPDATE ForeEver_Reservation
SET greenFees = (SELECT pricePerPlayer FROM fg_teeTimes WHERE teeTimeId = 7)
WHERE reservationId = '1004';
UPDATE ForeEver_Reservation
SET greenFees = (SELECT pricePerPlayer FROM fg_teeTimes WHERE teeTimeId = 9)
WHERE reservationId = '1005';

SELECT * FROM ForeEver_Reservation;
--Get taxes

UPDATE ForeEver_Reservation
SET taxes = greenFees * 0.5;

SELECT * FROM ForeEver_Reservation;

-- Apply promocode

UPDATE ForeEver_Reservation
SET greenFees = greenFees - ((SELECT promocodeValue FROM ForeEver_Rewards WHERE ReservationID = '1001')||0)
WHERE reservationId = '1001';
UPDATE ForeEver_Reservation
SET greenFees = greenFees - ((SELECT promocodeValue FROM ForeEver_Rewards WHERE ReservationID = '1002')||0)
WHERE reservationId = '1002';
UPDATE ForeEver_Reservation
SET greenFees = greenFees - ((SELECT promocodeValue FROM ForeEver_Rewards WHERE ReservationID = '1003')||0)
WHERE reservationId = '1003';
UPDATE ForeEver_Reservation
SET greenFees = greenFees - ((SELECT promocodeValue FROM ForeEver_Rewards WHERE ReservationID = '1004')||0)
WHERE reservationId = '1004';
UPDATE ForeEver_Reservation
SET greenFees = greenFees - ((SELECT promocodeValue FROM ForeEver_Rewards WHERE ReservationID = '1005')||0)
WHERE reservationId = '1005';

SELECT * FROM ForeEver_Reservation;

UPDATE ForeEver_Reservation
SET amountCharged = greenFees + taxes;




SELECT * FROM ForeEver_Reservation;
--create table fg_customerReview; 
CREATE TABLE fg_customerReview 
(
reviewTitle VARCHAR2(15) CONSTRAINT customerReview_Title_PK PRIMARY KEY, 
starRating NUMBER CONSTRAINT customerReview_Rating_NN NOT NULL, 
reviewComments VARCHAR2(80) CONSTRAINT customerReview_Comments_NN NOT NULL, 
Reservation_Id NUMBER, 
CONSTRAINT customerReview_Rating_CK CHECK(1 <= starRating and starRating <= 5 ), 
CONSTRAINT customerReview_Reservation_Id_FK FOREIGN KEY(Reservation_Id) REFERENCES ForeEver_Reservation(reservationId)
); 

DESC fg_customerReview; 

INSERT INTO fg_customerReview
VALUES ('Awesome Value', 5, 'Very good facilites, including range, carts, course', 1001);
INSERT INTO fg_customerReview
VALUES ('Shawneeki', 4, 't boxes not in good shape. Guy loading bags very good polite helpful', 1002); 
INSERT INTO fg_customerReview
VALUES ('Not bad', 3, 'Not a bad little course. it is better than the foot of snow we have in Michigan.', 1003);

SELECT * FROM fg_customerReview;

--sql code above
spool off
